<div class="mx-32">
    <div class="bg-biru rounded-lg">
        <div class="mx-8 py-10">
            <h1 class="font-Montserrat font-bold text-4xl text-white">Registration MLC 2022</h1>
            <h1 class="font-Montserrat font-bold text-4xl text-white">King/Queen of Mountain</h1>
            <p class="font-SourceSansPro text-xs text-white mt-4">isi sesuai dengan data di kartu identitas</p>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\issifix\resources\views/components/registerhead.blade.php ENDPATH**/ ?>