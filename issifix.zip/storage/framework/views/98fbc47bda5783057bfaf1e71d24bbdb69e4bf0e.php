<div class="mx-32">
    <div class="bg-biru rounded-lg">
        <div class="mx-8 py-10">
            <h1 class="font-Montserrat font-bold text-4xl text-white">Verifikasi Pembayaran</h1>
            <h1 class="font-Montserrat font-bold text-4xl text-white">MLC 2022</h1>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\issifix\resources\views/components/verifikasihead.blade.php ENDPATH**/ ?>