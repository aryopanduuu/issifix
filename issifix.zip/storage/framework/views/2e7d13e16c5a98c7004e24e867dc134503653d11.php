<div class="mx-4">
    <div class="bg-biru rounded-lg">
        <div class="mx-4 py-10">
            <h1 class="font-Montserrat font-bold text-2xl text-white">Registration MLC 2022</h1>
            <h1 class="font-Montserrat font-bold text-2xl text-white">King/Queen of Mountain</h1>
            <p class="font-SourceSansPro text-xs text-white mt-4">isi sesuai dengan data di kartu identitas</p>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\issifix\resources\views/components/mlc_register_head.blade.php ENDPATH**/ ?>