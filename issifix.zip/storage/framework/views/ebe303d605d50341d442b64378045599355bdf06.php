
<div>
    <img src="<?php echo e(asset('assets/cover.jpg')); ?>" alt="" class="h-screen object-cover">
</div><?php /**PATH C:\laragon\www\issifix\resources\views/components/hero.blade.php ENDPATH**/ ?>