<div class="mx-32 py-36">
    <h1 class="text-center font-Montserrat font-bold text-sm">Terima kasih telah melakukan verifikasi pembayaran tim kami akan melakukan crosscheck data.Mohon tunggu maksimal 1x24 jam. Untuk mengetahui proses verifikasi silahkan ke menu BOOKING STATUS. Apabila dalam waktu 1 x 24 jam tidak ada perubahan data silahkan hubungi kami di contact person. Terima Kasih</h1>
    <div class="grid grid-cols-2 mx-56 text-center gap-4 mt-8 text-white ">
        <div class="">
            <button class="bg-biru py-1 w-36">
                <a href="" class="font-Montserrat font-semibold">Booking Status</a>
            </button>
        </div>
        <div class="">
            <button class="bg-biru py-1 w-36">
                <a href="" class="font-Montserrat font-semibold">Home</a>
            </button>
        </div>
    </div>
</div>