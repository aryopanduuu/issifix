{{-- image --}}
<div>
    <img src="{{ asset('assets/cover.jpg') }}" alt="" class="h-screen object-cover">
</div>