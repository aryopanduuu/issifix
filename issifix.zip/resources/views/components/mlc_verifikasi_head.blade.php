<div class="mx-4">
    <div class="bg-biru rounded-lg">
        <div class="mx-8 py-10">
            <h1 class="font-Montserrat font-bold text-4xl text-white">Verifikasi Pembayaran</h1>
            <h1 class="font-Montserrat font-bold text-4xl text-white">MLC 2022</h1>
        </div>
    </div>
</div>